# Sambeid-Web
Proyecto de Ingeniería en Software 2022 S1. Sitio web para la socia comunitaria "Pasteleria Sambeid".
Integrantes: 
-Ignacio Arias
-Ignacio Arteaga
-Dylan Díaz
-Marcelo Mejías
-Francisco Parra

Tecnologías Usadas:
-HTML
-CSS
-JS
